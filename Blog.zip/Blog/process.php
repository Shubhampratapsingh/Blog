<?php
include('db.php');
if(isset($_POST['save']))
{
	$n=$_POST['name'];
	$enq=$_POST['enquiry'];
	$mob=$_POST['mobile'];
	
	$img=$_POST['img'];

	mysqli_query($conn,"INSERT INTO leadinfo(name,enquiry,mobile,img) values('$n','$enq','$mob','$img')") ;
	echo "<p allign=center>Data added successfully.</p>";
}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="index.html">Go back to home</a>
</body>
</html>
