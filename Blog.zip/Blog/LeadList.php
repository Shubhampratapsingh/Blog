<?php
include('db.php');
$result=mysqli_query($conn,"SELECT * FROM leadlist");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Blog</title>
	<link rel = "icon" href = "" type = "image/x-icon">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<h1 style="color: blue;">Post</h1>
	<style>
		body{
			font-family: cursive;
		}
		td{
			font-family: Times New Roman;
			font-size: 20px;
			padding: 20px;
			color: black;

		}
	</style>
	</head>
<body>
<table>
	<tr>
		<td>Name</td>
		<td>Mobile</td>
		<td>Email</td>
		<td>Blog Post</td>
		<td>Thanking Message</td>
	</tr>
	<?php
	 $i=0;
	 while ($row=mysqli_fetch_array($result)) {
	 	if($i%2==0)
	 		$classname="even";
	 	else
	 		$classname="odd";


	  ?>

	  <tr class="<?php if(isset($classname)) echo $classname;?>">
	  	<td><?php echo $row["name"]; ?></td>
	  	<td><?php echo $row["mobile"]; ?></td>
	  	<td><?php echo $row["email"]; ?></td>
	  	<td><?php echo $row["address"]; ?></td>
	  	<td><?php echo $row["area"]; ?></td>
	  	</tr>
	  <?php
	  $i++;
	}
	?>
</table>

</body>
</html>