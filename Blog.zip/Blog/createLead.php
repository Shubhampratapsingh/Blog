<!DOCTYPE html>
<html>
<head>
	<style>
		* { margin: 0px; padding: 0px; }
body {
	font-size: 120%;
	background: #F8F8FF;
}
.header {
	width: 40%;
	margin: 50px auto 0px;
	color: white;
	background: #5F9EA0;
	text-align: center;
	border: 1px solid #B0C4DE;
	border-bottom: none;
	border-radius: 10px 10px 0px 0px;
	padding: 20px;
}
form, .content {
	width: 40%;
	margin: 0px auto;
	padding: 20px;
	border: 1px solid #B0C4DE;
	background: white;
	border-radius: 0px 0px 10px 10px;
}
.input-group {
	margin: 10px 0px 10px 0px;
}
.input-group label {
	display: block;
	text-align: left;
	margin: 3px;
}
.input-group input {
	height: 30px;
	width: 93%;
	padding: 5px 10px;
	font-size: 16px;
	border-radius: 5px;
	border: 1px solid gray;
}
	</style>
	<title>Blog</title>
	<link rel = "icon" href = "" type = "image/x-icon">
	<div class="header">
	<h1 style="color: blue;">Create New Post:</h1>
</div>
</head>
<body>
<form method="post" action="processNew.php">
	<div class="input-group">
	 Writer Name:<br/>
	<input type="text" name="name"/>
</div>
	<br/>
	<div class="input-group">
	Mobile Number:<br/>
	<input type="number" name="mobile"/>
</div>
	<br/>
	<div class="input-group">
	Email:<br/>
	<input type="Email" name="email"/>
</div>
	<br/>
	<div class="input-group">
	Write Your Post:<br/>
	<input type="text" name="address"/>
</div>
	<br/>
	<div class="input-group">
	Thanking Message:<br/>
	<input type="text" name="area"/>
</div>
	<br/>
	<div class="input-group">
	<input type="submit" name="save" value="SUBMIT">
</div>
	<br/>
</form>
</body>
</html>