<?php
include('db.php');
if(isset($_POST['save']))
{
	$na=$_POST['name'];
	$mobile=$_POST['mobile'];
	$email=$_POST['email'];
	$address=$_POST['address'];
	$area=$_POST['area'];

	mysqli_query($conn,"INSERT INTO leadlist(name,mobile,email,address,area) values('$na','$mobile','$email','$address','$area')") ;
	echo "<p allign=center>Data added successfully.</p>";
}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="Home.html">Go back to home</a>
</body>
</html>
