<!DOCTYPE html>
<html>
<head>
	<style>

		* { margin: 0px; padding: 0px; }
body {
	font-size: 120%;
	background: #F8F8FF;
}
.header {
	width: 40%;
	margin: 50px auto 0px;
	color: white;
	background: #5F9EA0;
	text-align: center;
	border: 1px solid #B0C4DE;
	border-bottom: none;
	border-radius: 10px 10px 0px 0px;
	padding: 20px;
}
form, .content {
	width: 40%;
	margin: 0px auto;
	padding: 20px;
	border: 1px solid #B0C4DE;
	background: white;
	border-radius: 0px 0px 10px 10px;
}
.input-group {
	margin: 10px 0px 10px 0px;
}
.input-group label {
	display: block;
	text-align: left;
	margin: 3px;
}
.input-group input {
	height: 30px;
	width: 93%;
	padding: 5px 10px;
	font-size: 16px;
	border-radius: 5px;
	border: 1px solid gray;
}


	</style>
	<title>Blog</title>
	<link rel = "icon" href = "" type = "image/x-icon">
	<div class="header">
	<h1 style="color: blue;">Create New Request:</h1>
</div>
</head>
<body>
<form method="post" action="process.php">
	<div class="input-group">
	Topic Name:<br/>
	<input type="text" name="name"/>
</div>
	<br/>
	<div class="input-group">
	Enquiry Date:<br/>
	<input type="Date" name="enquiry"/>
</div>
	<br/>
	<div class="input-group">
	Mobile Number:<br/>
	<input type="number" name="mobile"/>
	<br/>
</div>
<div class="input-group">
	Upload Images(if any):<br/>
	<input type="file" name="img" />
</div>
	<br/>
	<div class="input-group">
	<input type="submit" name="save" value="SUBMIT">
</div>
	<br/>
</form>
</body>
</html>