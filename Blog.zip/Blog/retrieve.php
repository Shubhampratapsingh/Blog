<?php
include('db.php');
$result=mysqli_query($conn,"SELECT * FROM leadinfo");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Blog</title>
	<link rel = "icon" href = "" type = "image/x-icon">
	<link rel="stylesheet" type="text/css" href="style1.css">
	<h1 style="color: blue;">Topics Request:</h1>
	<style>
		body{
			font-family: cursive;
		}
		td{
			font-family: Times New Roman;
			font-size: 20px;
			padding: 20px;
			color: black;

		}
	</style>
	</head>
<body>
<table>
	<tr>
		<td>Request Id</td>
		<td>Topic Name</td>
		<td>Enquiry Date</td>
		<td>Mobile Number</td>
		<td>Images</td>
	</tr>
	<?php
	 $i=0;
	 while ($row=mysqli_fetch_array($result)) {
	 	if($i%2==0)
	 		$classname="even";
	 	else
	 		$classname="odd";


	  ?>

	  <tr class="<?php if(isset($classname)) echo $classname;?>">
	  	<td><?php echo $row["id"]; ?></td>
	  	<td><?php echo $row["name"]; ?></td>
	  	<td><?php echo $row["enquiry"]; ?></td>
	  	<td><?php echo $row["mobile"]; ?></td>
	  	<td> <img src="images/<?php echo $row["img"]; ?>"width='150' height='100' />
		</td>
	  	</tr>
	  <?php
	  $i++;
	}
	?>
</table>
</body>
</html>